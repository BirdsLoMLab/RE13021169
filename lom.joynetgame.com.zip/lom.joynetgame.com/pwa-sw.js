const clientId = 'hwH5Sdk'
const cacheStorageKey = `cacheStorageKey_${clientId}`

const indexFile = 'index.html'
const cacheList = [
  indexFile,
]

// 监听sw的install的事件
self.addEventListener('install', e => {
  //安装成功，调用e.waitUtill这个回调
  e.waitUntil(
    // 操作缓存，把index.html缓存起来
    caches.open(cacheStorageKey)
    .then(caches => {
      caches.addAll(cacheList)
    })
    .then(() => self.skipWaiting) //skipWaiting install 之后强制进入激活状态，跳过waiting状态
  )
})

// 监听页面发起的每个请求
self.addEventListener('fetch', function(e) {
  // 取请求的文件名fileName，这里只处理index.html，其他全部忽略
  const url = new URL(e.request.url)
  const fileName = url.pathname.split('/').pop()
  if(fileName && fileName !== indexFile) {
    return
  }
  // 每次都重新发起网络请求并返回请求结果
  // 除非请求异常（如断网）则返回缓存中的index.html
  e.respondWith(
    caches.match(e.request)
    .then(function (response) {
      const request = e.request.clone();
      return fetch(request).then(function (httpRes) {
        if (!httpRes || httpRes.status !== 200) {
          return response != null ? response : httpRes
        }
        // 更新index.html缓存
        const responseClone = httpRes.clone()
        caches.open(cacheStorageKey).then(function (caches) {
          caches.put(e.request, responseClone)
        })
        return httpRes
      }).catch(() => {
        // 请求异常，返回缓存结果
        return response
      })
    })
  )
 })

